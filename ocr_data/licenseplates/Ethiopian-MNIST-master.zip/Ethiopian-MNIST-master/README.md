# Ethiopian-MNIST
Letters dataset for Ethiopian(Amharic) language

<h1> This is an open source dataset for Amharic letters</h1>



If there is anyone who wants to contribute to this dataset, I will be more than happy.
